create definer = root@localhost trigger `statistic Log`
    after insert
    on openvas_result
    for each row
    UPDATE statistic_job SET statistic_job.Log = (SELECT COUNT(openvas_result.threat) FROM openvas_result WHERE openvas_result.threat ='Log') WHERE statistic_job.id_statistic ='1';

